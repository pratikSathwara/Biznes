$(document).ready(function(){
  
	// SLIDER
	//$('.slider').slick({});
		
  $('.slider').slick({
    dots: true,
    speed: 1000,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 3000,
    nextArrow: false,
    prevArrow: false,
  });
  $('.client').slick({
    dots: true,
    speed: 1000,
    infinite: true,
    // autoplay: true,
    autoplaySpeed: 3000,
    nextArrow: false,
    prevArrow: false,
  });




  $('.service').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    centerMode: true,
    arrows: true,
    dots: false,
    speed: 300,
    centerPadding: '10px',
    infinite: true,
    autoplaySpeed: 5000,
    autoplay: true,
    nextArrow: '<div class="slick-custom-arrow slick-custom-arrow-right"><i class="fa fa-angle-right"></i></div>',
    prevArrow: '<div class="slick-custom-arrow slick-custom-arrow-left"><i class="fa fa-angle-left"></i></div>',
              responsive: [                        
              {
                breakpoint: 576,settings: {
                slidesToShow: 1,}
              },
              {
                breakpoint: 768,settings: {
                slidesToShow: 2,}
              },
              {
                breakpoint: 991,settings: {
                slidesToShow: 4,}
              },
          ]
  });
});